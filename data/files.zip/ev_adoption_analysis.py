#!/usr/bin/env python3
"""
Electric Vehicle Adoption Intelligence:
Data-Driven Analysis and Growth Prediction Across Indian States
Subject: Fundamentals of Data Science
Team   : Dhruv Pandey (590028550), Aryan Sejwal (590023034)

Full pipeline (CRISP-DM): load -> quality assessment -> cleaning -> EDA ->
statistics -> feature engineering (selection, transformation, PCA) ->
models (Linear Regression, Decision Tree, Logistic Regression, KNN,
K-Means, Hierarchical) -> evaluation -> saved tables and figures.

Inputs  (CSV, in --data-dir, default ./data):
  ev_registrations.csv : state, month, vehicle_category, ev_registrations, total_registrations
  charging_stations.csv: state, public_charging_stations   (optional)

Usage:
  python ev_adoption_analysis.py                 # real data in ./data
  python ev_adoption_analysis.py --selftest      # synthetic data, to test your setup ONLY

Everything written to --out-dir (tables/ and figures/) is computed from the
input files. Nothing is hard-coded or invented.
"""
import argparse
import json
import re
import sys
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
from sklearn.cluster import AgglomerativeClustering, KMeans
from sklearn.decomposition import PCA
from sklearn.feature_selection import f_regression, mutual_info_regression
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.metrics import (accuracy_score, confusion_matrix, f1_score,
                             mean_absolute_error, mean_squared_error,
                             r2_score, silhouette_score)
from sklearn.model_selection import (GridSearchCV, RepeatedStratifiedKFold,
                                     StratifiedKFold, TimeSeriesSplit,
                                     cross_val_predict, cross_validate)
from sklearn.neighbors import KNeighborsClassifier
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.tree import DecisionTreeClassifier, DecisionTreeRegressor, plot_tree

warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=UserWarning)

SEED = 42
START_DATE = pd.Timestamp("2025-01-01")        # project rule: data not older than 2025
REQUIRED_COLS = ["state", "month", "vehicle_category", "ev_registrations", "total_registrations"]
KEY_COLS = ["state", "month", "vehicle_category"]
COUNT_COLS = ["ev_registrations", "total_registrations"]
CATEGORIES = ["2W", "3W", "4W", "Bus", "Other"]
TIERS = ["Low", "Medium", "High"]
WATERMARK = False                               # set True in --selftest

sns.set_theme(style="whitegrid", context="notebook")


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #
def log(msg):
    print(msg, flush=True)


def save_fig(fig, path):
    if WATERMARK:
        fig.text(0.5, 0.5, "SELFTEST - SYNTHETIC DATA", color="red", alpha=0.25,
                 fontsize=34, ha="center", va="center", rotation=25)
    fig.tight_layout()
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    log(f"   saved {path}")


class QualityLog:
    """Collects one row per data-quality check (report Section 3.5)."""

    def __init__(self):
        self.rows = []

    def add(self, check, rows, action):
        self.rows.append({"quality_check": check, "rows_affected": int(rows), "action_taken": action})

    def to_df(self):
        return pd.DataFrame(self.rows)


def _norm(text):
    s = str(text).lower().replace("&", " and ")
    s = re.sub(r"[^a-z0-9 ]", " ", s)
    return re.sub(r"\s+", " ", s).strip()


CANONICAL_STATES = [
    "Andaman and Nicobar Islands", "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar",
    "Chandigarh", "Chhattisgarh", "Dadra and Nagar Haveli and Daman and Diu", "Delhi", "Goa",
    "Gujarat", "Haryana", "Himachal Pradesh", "Jammu and Kashmir", "Jharkhand", "Karnataka",
    "Kerala", "Ladakh", "Lakshadweep", "Madhya Pradesh", "Maharashtra", "Manipur", "Meghalaya",
    "Mizoram", "Nagaland", "Odisha", "Puducherry", "Punjab", "Rajasthan", "Sikkim", "Tamil Nadu",
    "Telangana", "Tripura", "Uttar Pradesh", "Uttarakhand", "West Bengal",
]
_STATE_MAP = {_norm(s): s for s in CANONICAL_STATES}
_STATE_MAP.update({
    "andaman and nicobar island": "Andaman and Nicobar Islands",
    "andaman nicobar islands": "Andaman and Nicobar Islands",
    "dadra and nagar haveli": "Dadra and Nagar Haveli and Daman and Diu",
    "daman and diu": "Dadra and Nagar Haveli and Daman and Diu",
    "dnh and dd": "Dadra and Nagar Haveli and Daman and Diu",
    "nct of delhi": "Delhi", "national capital territory of delhi": "Delhi", "new delhi": "Delhi",
    "jammu and kashmir ut": "Jammu and Kashmir", "orissa": "Odisha", "pondicherry": "Puducherry",
    "uttaranchal": "Uttarakhand", "chattisgarh": "Chhattisgarh", "telengana": "Telangana",
    "tamilnadu": "Tamil Nadu", "tamil nadu state": "Tamil Nadu",
})

_CAT_MAP = {}
for _label, _names in {
    "2W": ["2w", "two wheeler", "two wheelers", "twowheeler", "e 2w", "e2w", "2 wheeler"],
    "3W": ["3w", "three wheeler", "three wheelers", "threewheeler", "e 3w", "e3w", "3 wheeler",
           "e rickshaw", "erickshaw", "e cart"],
    "4W": ["4w", "four wheeler", "four wheelers", "fourwheeler", "lmv", "e 4w", "e4w", "car",
           "cars", "passenger", "passenger vehicle", "e pv", "4 wheeler"],
    "Bus": ["bus", "buses", "e bus", "ebus"],
    "Other": ["other", "others", "goods", "e goods carrier", "heavy goods vehicle", "commercial"],
}.items():
    for _n in _names:
        _CAT_MAP[_norm(_n)] = _label


def standardise_state_names(series):
    """Map spelling variants of state names to one official name (report Section 3.1)."""
    def fix(x):
        if pd.isna(x):
            return x
        key = _norm(x)
        return _STATE_MAP.get(key, " ".join(w.capitalize() for w in key.split()))
    return series.map(fix).astype("string")


def standardise_categories(series):
    """Map vehicle-class labels to 2W / 3W / 4W / Bus / Other."""
    def fix(x):
        if pd.isna(x):
            return x
        return _CAT_MAP.get(_norm(x), "Other")
    return series.map(fix).astype("string")


def parse_month(series):
    """Parse YYYY-MM (preferred) or any common date text to the first day of the month."""
    s = series.astype("string")
    out = pd.to_datetime(s, format="%Y-%m", errors="coerce")
    rest = out.isna() & s.notna()
    if rest.any():
        out.loc[rest] = pd.to_datetime(s[rest], errors="coerce")
    return out.dt.to_period("M").dt.to_timestamp()


# --------------------------------------------------------------------------- #
# 1. Load + clean (CRISP-DM: data understanding / preparation)
# --------------------------------------------------------------------------- #
def clean_registrations(raw):
    q = QualityLog()
    df = raw.copy()
    df.columns = [str(c).strip().lower() for c in df.columns]
    absent = [c for c in REQUIRED_COLS if c not in df.columns]
    if absent:
        raise ValueError(f"ev_registrations.csv is missing columns: {absent}. Expected: {REQUIRED_COLS}")
    df = df[REQUIRED_COLS].copy()
    n_raw = len(df)
    q.add("Raw rows loaded", n_raw, "None")

    for c in ("state", "month", "vehicle_category"):
        df[c] = df[c].astype("string").str.strip()

    # standardise names / labels
    orig_state = df["state"].copy()
    df["state"] = standardise_state_names(df["state"])
    changed = (orig_state.fillna("") != df["state"].fillna("")) & orig_state.notna()
    q.add("State names standardised", changed.sum(), "Mapped to one official name each")
    unknown = df["state"].notna() & ~df["state"].isin(CANONICAL_STATES)
    q.add("Unrecognised state names", unknown.sum(), "Kept as typed; check spelling in the source file")
    orig_cat = df["vehicle_category"].copy()
    df["vehicle_category"] = standardise_categories(df["vehicle_category"])
    q.add("Vehicle category labels mapped", ((orig_cat.fillna("") != df["vehicle_category"].fillna("")) & orig_cat.notna()).sum(),
          "Mapped to 2W/3W/4W/Bus/Other")

    # types
    df["month"] = parse_month(df["month"])
    unparse = 0
    for c in COUNT_COLS:
        was_na = df[c].isna()
        df[c] = pd.to_numeric(df[c], errors="coerce")
        unparse += int((df[c].isna() & ~was_na).sum())
    q.add("Unparseable numeric values", unparse, "Converted to missing, handled below")

    # period rule
    old = df["month"] < START_DATE
    q.add("Months before 2025 removed", old.sum(), "Removed (project rule: data not older than 2025)")
    df = df[~old].copy()

    # duplicates
    dup = df.duplicated(subset=KEY_COLS, keep="first")
    q.add("Duplicate rows removed", dup.sum(), "Kept first record per state, month and category")
    df = df[~dup].copy()

    # missing values
    miss_any = df[REQUIRED_COLS].isna().any(axis=1)
    fill_zero = df["ev_registrations"].isna() & df["total_registrations"].notna() & ~df[KEY_COLS].isna().any(axis=1)
    df.loc[fill_zero, "ev_registrations"] = 0
    drop_missing = df[REQUIRED_COLS].isna().any(axis=1)
    q.add("Rows with missing values", miss_any.sum(),
          f"{int(fill_zero.sum())} EV counts set to 0 (total present); {int(drop_missing.sum())} rows dropped")
    n_dropped_missing = int(drop_missing.sum())
    df = df[~drop_missing].copy()
    if n_raw and n_dropped_missing / n_raw > 0.05:
        log(f"   WARNING: {n_dropped_missing / n_raw:.1%} of rows dropped for missing values - check your export.")

    # impossible values
    neg = (df["ev_registrations"] < 0) | (df["total_registrations"] < 0)
    df = df[~neg].copy()
    over = df["ev_registrations"] > df["total_registrations"]
    df.loc[over, "ev_registrations"] = df.loc[over, "total_registrations"]
    q.add("Impossible values fixed", int(neg.sum() + over.sum()),
          f"{int(neg.sum())} negative-count rows removed; {int(over.sum())} rows with EV > total capped at total")

    df = flag_outliers(df, q)
    df["ev_registrations"] = df["ev_registrations"].astype(float)
    df["total_registrations"] = df["total_registrations"].astype(float)
    df = df.sort_values(["month", "state", "vehicle_category"]).reset_index(drop=True)
    q.add("Clean rows used for analysis", len(df), "None")
    return df, q


def flag_outliers(df, q):
    """IQR rule on log(1+EV). Flag only - large states are real, not errors (report Section 3.3)."""
    x = np.log1p(df["ev_registrations"])
    q1, q3 = x.quantile(0.25), x.quantile(0.75)
    iqr = q3 - q1
    df = df.copy()
    df["outlier_flag"] = (x > q3 + 1.5 * iqr) | (x < q1 - 1.5 * iqr)
    q.add("Outlier rows flagged (kept)", int(df["outlier_flag"].sum()), "None (flag only)")
    return df


def load_charging(path):
    if not path.exists():
        log("   charging_stations.csv not found -> charging-station features will be skipped.")
        return None
    c = pd.read_csv(path)
    c.columns = [str(x).strip().lower() for x in c.columns]
    if not {"state", "public_charging_stations"} <= set(c.columns):
        log("   charging_stations.csv needs columns state, public_charging_stations -> skipped.")
        return None
    c["state"] = standardise_state_names(c["state"].astype("string").str.strip())
    c["public_charging_stations"] = pd.to_numeric(c["public_charging_stations"], errors="coerce")
    c = c.dropna().drop_duplicates(subset="state", keep="first")
    return c[["state", "public_charging_stations"]]


# --------------------------------------------------------------------------- #
# 2. Feature tables (CRISP-DM: data preparation)
# --------------------------------------------------------------------------- #
def build_state_features(clean, charging):
    st = clean.groupby("state").agg(total_ev=("ev_registrations", "sum"),
                                    total_vehicles=("total_registrations", "sum"))
    st["ev_share_pct"] = 100 * st["total_ev"] / st["total_vehicles"].replace(0, np.nan)
    by_cat = clean.pivot_table(index="state", columns="vehicle_category", values="ev_registrations",
                               aggfunc="sum", fill_value=0)
    for c in ("2W", "3W", "4W"):
        col = by_cat[c] if c in by_cat.columns else 0
        st[f"share_{c.lower()}"] = col / st["total_ev"].replace(0, np.nan)

    months = sorted(clean["month"].unique())
    half = len(months) // 2
    if half >= 1:
        h1, h2 = months[:half], months[-half:]
        a = clean[clean["month"].isin(h1)].groupby("state")["ev_registrations"].sum()
        b = clean[clean["month"].isin(h2)].groupby("state")["ev_registrations"].sum()
        st["growth_h2_vs_h1_pct"] = 100 * (b - a) / a.replace(0, np.nan)
    else:
        st["growth_h2_vs_h1_pct"] = np.nan

    if charging is not None:
        st = st.join(charging.set_index("state").rename(columns={"public_charging_stations": "charging_stations"}))
        st["stations_per_10k"] = 10000 * st["charging_stations"] / st["total_vehicles"].replace(0, np.nan)
    st["log_total_ev"] = np.log1p(st["total_ev"])
    st = st.reset_index()
    return st, months


def fill_median(df, cols, name):
    df = df.copy()
    for c in cols:
        n = int(df[c].isna().sum())
        if n:
            log(f"   {name}: {n} missing value(s) in '{c}' filled with the median.")
            df[c] = df[c].fillna(df[c].median())
    return df


def build_panel(clean, charging):
    p = clean.groupby(["state", "month"]).agg(ev_registrations=("ev_registrations", "sum"),
                                              total_registrations=("total_registrations", "sum")).reset_index()
    months = sorted(p["month"].unique())
    p["month_idx"] = p["month"].map({m: i + 1 for i, m in enumerate(months)})
    p = p.sort_values(["state", "month"])
    p["lag_1_ev"] = p.groupby("state")["ev_registrations"].shift(1)
    p = p.dropna(subset=["lag_1_ev"]).copy()
    p["log_total_registrations"] = np.log1p(p["total_registrations"])
    p["log_lag_1_ev"] = np.log1p(p["lag_1_ev"])
    feats = ["month_idx", "log_total_registrations", "log_lag_1_ev"]
    if charging is not None:
        p = p.merge(charging, on="state", how="left")
        p["public_charging_stations"] = p["public_charging_stations"].fillna(p["public_charging_stations"].median())
        p["log_charging_stations"] = np.log1p(p["public_charging_stations"])
        feats.insert(2, "log_charging_stations")
    p["target_log_ev"] = np.log1p(p["ev_registrations"])
    p = p.sort_values(["month_idx", "state"]).reset_index(drop=True)
    return p, feats, len(months)


def correlation_filter(X, threshold=0.9):
    """Drop the later feature of any pair with |r| > threshold (report Section 6.3)."""
    corr = X.corr().abs()
    drop = set()
    cols = list(X.columns)
    for i, a in enumerate(cols):
        for b in cols[i + 1:]:
            if a not in drop and b not in drop and corr.loc[a, b] > threshold:
                drop.add(b)
    return [c for c in cols if c not in drop], sorted(drop)


# --------------------------------------------------------------------------- #
# 3. EDA figures (report Section 4)
# --------------------------------------------------------------------------- #
def eda_figures(clean, st, fig_dir):
    # 01 bar chart: states by volume and by share
    fig, ax = plt.subplots(1, 2, figsize=(13, 6))
    top = st.nlargest(15, "total_ev").iloc[::-1]
    ax[0].barh(top["state"], top["total_ev"], color="#1b9e77")
    ax[0].set_title("Top 15 states by EV registrations")
    ax[0].set_xlabel("EV registrations")
    top2 = st.nlargest(15, "ev_share_pct").iloc[::-1]
    ax[1].barh(top2["state"], top2["ev_share_pct"], color="#7570b3")
    ax[1].set_title("Top 15 states by EV share of all registrations")
    ax[1].set_xlabel("EV share (%)")
    save_fig(fig, fig_dir / "01_state_bar.png")

    # 02 category comparison: volume and growth
    by_cat = clean.groupby("vehicle_category")["ev_registrations"].sum().reindex(CATEGORIES).dropna()
    months = sorted(clean["month"].unique())
    half = len(months) // 2
    growth = pd.Series(dtype=float)
    if half >= 1:
        a = clean[clean["month"].isin(months[:half])].groupby("vehicle_category")["ev_registrations"].sum()
        b = clean[clean["month"].isin(months[-half:])].groupby("vehicle_category")["ev_registrations"].sum()
        growth = (100 * (b - a) / a.replace(0, np.nan)).reindex(by_cat.index)
    fig, ax = plt.subplots(1, 2, figsize=(12, 4.8))
    ax[0].bar(by_cat.index, by_cat.values, color="#1b9e77")
    ax[0].set_title("EV registrations by vehicle category")
    ax[0].set_ylabel("EV registrations")
    if len(growth):
        ax[1].bar(growth.index, growth.values, color="#d95f02")
        ax[1].axhline(0, color="black", lw=0.8)
    ax[1].set_title("Growth: second half vs first half of the period (%)")
    save_fig(fig, fig_dir / "02_category_comparison.png")

    # 03 monthly trend
    mc = clean.pivot_table(index="month", columns="vehicle_category", values="ev_registrations", aggfunc="sum").fillna(0)
    tot = clean.groupby("month")[["ev_registrations", "total_registrations"]].sum()
    fig, ax = plt.subplots(1, 2, figsize=(13, 4.8))
    for c in [c for c in CATEGORIES if c in mc.columns]:
        ax[0].plot(mc.index, mc[c], marker="o", label=c)
    ax[0].set_title("National EV registrations by month and category")
    ax[0].legend()
    ax[0].tick_params(axis="x", rotation=45)
    ax[1].plot(tot.index, 100 * tot["ev_registrations"] / tot["total_registrations"], marker="o", color="#7570b3")
    ax[1].set_title("EV share of all registrations by month (%)")
    ax[1].tick_params(axis="x", rotation=45)
    save_fig(fig, fig_dir / "03_monthly_trend.png")

    # 04 histograms
    fig, ax = plt.subplots(1, 3, figsize=(14, 4.2))
    bins = max(5, min(15, len(st) // 2))
    ax[0].hist(st["total_ev"], bins=bins, color="#1b9e77")
    ax[0].set_title("State EV registrations (raw)")
    ax[1].hist(np.log10(st["total_ev"].clip(lower=1)), bins=bins, color="#d95f02")
    ax[1].set_title("State EV registrations (log10)")
    ax[2].hist(st["ev_share_pct"].dropna(), bins=bins, color="#7570b3")
    ax[2].set_title("State EV share (%)")
    for a in ax:
        a.set_ylabel("Number of states")
    save_fig(fig, fig_dir / "04_histogram_state_ev.png")

    # 05 scatter: charging stations (or market size) vs EV registrations
    xcol = "charging_stations" if "charging_stations" in st.columns else "total_vehicles"
    d = st[[xcol, "total_ev", "state"]].dropna()
    d = d[(d[xcol] > 0) & (d["total_ev"] > 0)]
    fig, ax = plt.subplots(figsize=(7.5, 5.5))
    ax.scatter(d[xcol], d["total_ev"], color="#1b9e77", s=45)
    if len(d) >= 3:
        slope, intercept = np.polyfit(np.log10(d[xcol]), np.log10(d["total_ev"]), 1)
        xs = np.linspace(d[xcol].min(), d[xcol].max(), 100)
        ax.plot(xs, 10 ** (intercept + slope * np.log10(xs)), color="#d95f02", lw=2, label="log-log trend")
        ax.legend()
    for _, r in d.nlargest(5, "total_ev").iterrows():
        ax.annotate(r["state"], (r[xcol], r["total_ev"]), fontsize=8, xytext=(4, 4), textcoords="offset points")
    ax.set_xscale("log")
    ax.set_yscale("log")
    ax.set_xlabel("Public charging stations" if xcol == "charging_stations" else "Total vehicle registrations (market size)")
    ax.set_ylabel("EV registrations")
    ax.set_title("Charging stations vs EV registrations" if xcol == "charging_stations"
                 else "Market size vs EV registrations (no charging file)")
    save_fig(fig, fig_dir / "05_scatter_charging_vs_ev.png")

    # 06 heatmap
    num = st.select_dtypes("number").drop(columns=["log_total_ev"], errors="ignore")
    fig, ax = plt.subplots(figsize=(9, 7.5))
    sns.heatmap(num.corr(), annot=True, fmt=".2f", cmap="RdBu_r", center=0, vmin=-1, vmax=1, ax=ax, annot_kws={"size": 8})
    ax.set_title("Correlation heatmap of state-level features")
    save_fig(fig, fig_dir / "06_correlation_heatmap.png")


# --------------------------------------------------------------------------- #
# 4. Statistical analysis (report Section 5)
# --------------------------------------------------------------------------- #
def safe(func, *a, **k):
    try:
        return func(*a, **k)
    except Exception:
        return (np.nan, np.nan)


def statistical_analysis(clean, st, tab_dir):
    cols = [c for c in ["total_ev", "ev_share_pct", "charging_stations", "growth_h2_vs_h1_pct", "stations_per_10k"] if c in st.columns]
    d = st[cols].describe().T
    d["median"] = st[cols].median()
    d["skewness"] = st[cols].skew()
    d.to_csv(tab_dir / "descriptive_stats.csv", index_label="variable")

    num = st.select_dtypes("number")
    num.corr().to_csv(tab_dir / "correlation_matrix.csv")

    rows = []
    # normality
    for c in cols:
        x = st[c].dropna()
        if len(x) >= 3:
            w, p = safe(stats.shapiro, x)
            rows.append({"test": "Shapiro-Wilk (raw)", "variable": c, "statistic": w, "p_value": p, "n": len(x)})
            if (x >= 0).all():
                w, p = safe(stats.shapiro, np.log1p(x))
                rows.append({"test": "Shapiro-Wilk (log1p)", "variable": c, "statistic": w, "p_value": p, "n": len(x)})

    # T1: first half vs second half, paired by state (Wilcoxon)
    months = sorted(clean["month"].unique())
    half = len(months) // 2
    if half >= 1:
        a = clean[clean["month"].isin(months[:half])].groupby("state")["ev_registrations"].sum()
        b = clean[clean["month"].isin(months[-half:])].groupby("state")["ev_registrations"].sum()
        j = pd.concat([a, b], axis=1, keys=["h1", "h2"]).dropna()
        s, p = safe(stats.wilcoxon, j["h1"], j["h2"])
        rows.append({"test": "T1 Wilcoxon signed-rank: first vs second half", "variable": "ev_registrations by state",
                     "statistic": s, "p_value": p, "n": len(j)})

    # T2: EV share differs across categories (Kruskal-Wallis)
    cs = clean.groupby(["state", "vehicle_category"])[COUNT_COLS].sum().reset_index()
    cs = cs[cs["total_registrations"] > 0]
    cs["share"] = cs["ev_registrations"] / cs["total_registrations"]
    groups = [g["share"].values for _, g in cs.groupby("vehicle_category") if len(g) >= 3]
    if len(groups) >= 2:
        s, p = safe(stats.kruskal, *groups)
        rows.append({"test": "T2 Kruskal-Wallis: EV share across categories", "variable": "ev share by category",
                     "statistic": s, "p_value": p, "n": sum(len(g) for g in groups)})

    # T3 + correlation pairs
    pairs = [("charging_stations", "total_ev"), ("total_vehicles", "total_ev"),
             ("stations_per_10k", "ev_share_pct"), ("share_2w", "ev_share_pct")]
    prow = []
    for x, y in pairs:
        if x in st.columns and y in st.columns:
            d2 = st[[x, y]].dropna()
            if len(d2) >= 4:
                r, pr = safe(stats.pearsonr, d2[x], d2[y])
                rho, ps = safe(stats.spearmanr, d2[x], d2[y])
                prow.append({"pair": f"{x} vs {y}", "pearson_r": r, "pearson_p": pr,
                             "spearman_rho": rho, "spearman_p": ps, "n": len(d2)})
                if (x, y) == ("charging_stations", "total_ev"):
                    rows.append({"test": "T3 Spearman: charging stations vs EV registrations", "variable": f"{x} vs {y}",
                                 "statistic": rho, "p_value": ps, "n": len(d2)})
    pd.DataFrame(rows).to_csv(tab_dir / "stat_tests.csv", index=False)
    pd.DataFrame(prow).to_csv(tab_dir / "correlation_pairs.csv", index=False)
    return pd.DataFrame(rows), pd.DataFrame(prow)


# --------------------------------------------------------------------------- #
# 5. Regression (report Sections 6.3, 7.2-7.5, 8.1)
# --------------------------------------------------------------------------- #
def rmse(y, p):
    return float(np.sqrt(mean_squared_error(y, p)))


def regression_models(panel, feats, n_months, tab_dir, fig_dir):
    n_test = max(1, n_months // 4)
    cut = n_months - n_test
    train = panel[panel["month_idx"] <= cut].sort_values(["month_idx", "state"])
    test = panel[panel["month_idx"] > cut]
    if len(train) < 20 or len(test) < 5:
        log("   Not enough monthly data for regression (need several months and states) - skipped.")
        return None
    log(f"   train months 1-{cut} ({len(train)} rows) | test months {cut + 1}-{n_months} ({len(test)} rows)")

    Xtr, ytr = train[feats], train["target_log_ev"]
    Xte, yte_true = test[feats], test["ev_registrations"].values

    # feature selection scores (report Section 6.3)
    f, pf = f_regression(Xtr, ytr)
    mi = mutual_info_regression(Xtr, ytr, random_state=SEED)
    cm = Xtr.corr().abs()
    maxc = [float(cm.loc[c].drop(c).max()) for c in feats]
    scores = pd.DataFrame({"feature": feats, "f_score": f, "f_p_value": pf, "mutual_information": mi,
                           "max_abs_corr_with_other_feature": maxc})
    scores["flag"] = np.where(scores["max_abs_corr_with_other_feature"] > 0.9, "highly correlated (>0.9) - check", "ok")
    scores.to_csv(tab_dir / "feature_scores.csv", index=False)

    inv = lambda z: np.clip(np.expm1(z), 0, None)
    results = []

    base_last = inv(Xte["log_lag_1_ev"].values)
    results.append(("Baseline: same as last month", base_last))
    results.append(("Baseline: training mean", np.full(len(test), train["ev_registrations"].mean())))

    lr = make_pipeline(StandardScaler(), LinearRegression()).fit(Xtr, ytr)
    pred_lr = inv(lr.predict(Xte))
    results.append(("Linear Regression", pred_lr))

    grid = {"max_depth": [2, 3, 4, 5, 6, 8], "min_samples_leaf": [1, 3, 5, 10]}
    gs = GridSearchCV(DecisionTreeRegressor(random_state=SEED), grid, cv=TimeSeriesSplit(n_splits=3),
                      scoring="neg_mean_absolute_error").fit(Xtr, ytr)
    dt = gs.best_estimator_
    pred_dt = inv(dt.predict(Xte))
    results.append(("Decision Tree Regressor", pred_dt))
    log(f"   Decision Tree best params: {gs.best_params_}")

    metrics = pd.DataFrame([{"model": n, "MAE": mean_absolute_error(yte_true, p), "RMSE": rmse(yte_true, p),
                             "R2": r2_score(yte_true, p)} for n, p in results])
    metrics.to_csv(tab_dir / "regression_metrics.csv", index=False)

    imp = pd.DataFrame({"feature": feats,
                        "linear_regression_standardised_coef": lr[-1].coef_,
                        "decision_tree_importance": dt.feature_importances_})
    imp.to_csv(tab_dir / "feature_importance.csv", index=False)

    # figures
    fig, ax = plt.subplots(figsize=(6.5, 6))
    ax.scatter(yte_true + 1, pred_lr + 1, alpha=0.6, label="Linear Regression", color="#1b9e77")
    ax.scatter(yte_true + 1, pred_dt + 1, alpha=0.6, label="Decision Tree", color="#d95f02", marker="^")
    lim = [min(yte_true.min(), 0) + 1, max(yte_true.max(), pred_lr.max(), pred_dt.max()) + 1]
    ax.plot(lim, lim, "k--", lw=1, label="perfect prediction")
    ax.set_xscale("log")
    ax.set_yscale("log")
    ax.set_xlabel("Actual monthly EV registrations (+1)")
    ax.set_ylabel("Predicted (+1)")
    ax.set_title("Actual vs predicted (test months)")
    ax.legend()
    save_fig(fig, fig_dir / "10_actual_vs_pred.png")

    fig, ax = plt.subplots(figsize=(15, 7))
    plot_tree(dt, feature_names=feats, filled=True, rounded=True, max_depth=3, fontsize=8, ax=ax)
    ax.set_title("Decision Tree Regressor (top 3 levels; target = log(1 + EV registrations))")
    save_fig(fig, fig_dir / "11_decision_tree.png")

    return {"metrics": metrics, "importance": imp, "best_params": gs.best_params_,
            "train_months": f"1-{cut}", "test_months": f"{cut + 1}-{n_months}"}


# --------------------------------------------------------------------------- #
# 6. Classification (report Sections 7.6, 8.2)
# --------------------------------------------------------------------------- #
def classification_models(st, tab_dir, fig_dir):
    d = st.dropna(subset=["ev_share_pct"]).copy()
    d["tier"] = pd.qcut(d["ev_share_pct"].rank(method="first"), 3, labels=TIERS)
    cand = [c for c in ["stations_per_10k", "share_2w", "share_3w", "share_4w", "growth_h2_vs_h1_pct", "log_total_ev"] if c in d.columns]
    d = fill_median(d, cand, "classification")
    X, y = d[cand], d["tier"].astype(str)
    min_class = int(y.value_counts().min())
    if len(d) < 12 or min_class < 3:
        log("   Too few states for classification - skipped.")
        return None
    n_splits = min(5, min_class)
    knn_k = max(1, min(5, len(d) - len(d) // n_splits - 1))
    models = {
        "Decision Tree Classifier": DecisionTreeClassifier(max_depth=3, min_samples_leaf=2, random_state=SEED),
        "Logistic Regression": make_pipeline(StandardScaler(), LogisticRegression(max_iter=2000)),
        "KNN": make_pipeline(StandardScaler(), KNeighborsClassifier(n_neighbors=knn_k)),
    }
    cv = RepeatedStratifiedKFold(n_splits=n_splits, n_repeats=10, random_state=SEED)
    rows, preds = [], {}
    for name, m in models.items():
        r = cross_validate(m, X, y, cv=cv, scoring=["accuracy", "f1_macro"])
        rows.append({"model": name, "accuracy_mean": r["test_accuracy"].mean(), "accuracy_std": r["test_accuracy"].std(),
                     "macro_f1_mean": r["test_f1_macro"].mean(), "macro_f1_std": r["test_f1_macro"].std()})
        preds[name] = cross_val_predict(m, X, y, cv=StratifiedKFold(n_splits, shuffle=True, random_state=SEED))
    res = pd.DataFrame(rows)
    res.to_csv(tab_dir / "classification_metrics.csv", index=False)
    best = res.sort_values("accuracy_mean", ascending=False).iloc[0]["model"]
    cmat = confusion_matrix(y, preds[best], labels=TIERS)
    pd.DataFrame(cmat, index=[f"actual_{t}" for t in TIERS], columns=[f"pred_{t}" for t in TIERS]).to_csv(
        tab_dir / "confusion_matrix.csv")
    fig, ax = plt.subplots(figsize=(5.5, 4.8))
    sns.heatmap(cmat, annot=True, fmt="d", cmap="Blues", xticklabels=TIERS, yticklabels=TIERS, ax=ax)
    ax.set_xlabel("Predicted tier")
    ax.set_ylabel("Actual tier")
    ax.set_title(f"Confusion matrix: {best}\n(cross-validated predictions, accuracy {accuracy_score(y, preds[best]):.2f})")
    save_fig(fig, fig_dir / "12_confusion_matrix.png")
    return {"metrics": res, "best": best, "features": cand}


# --------------------------------------------------------------------------- #
# 7. PCA + clustering (report Sections 6.4, 7.7, 8.3)
# --------------------------------------------------------------------------- #
def pca_and_clustering(st, tab_dir, fig_dir):
    cand = [c for c in ["ev_share_pct", "log_total_ev", "stations_per_10k", "growth_h2_vs_h1_pct",
                        "share_2w", "share_3w", "share_4w"] if c in st.columns]
    d = fill_median(st.dropna(subset=["ev_share_pct"]).copy(), cand, "clustering")
    kept, dropped = correlation_filter(d[cand], 0.9)
    if dropped:
        log(f"   correlation filter (>0.9) dropped: {dropped}")
    d = d.reset_index(drop=True)
    if len(d) < 8:
        log("   Too few states for clustering - skipped.")
        return None
    Z = StandardScaler().fit_transform(d[kept])

    # PCA
    pca = PCA(random_state=SEED).fit(Z)
    ev = pca.explained_variance_ratio_
    cum = np.cumsum(ev)
    n90 = int(np.searchsorted(cum, 0.90) + 1)
    rows = []
    for i in range(len(ev)):
        top = pd.Series(np.abs(pca.components_[i]), index=kept).nlargest(3).index.tolist()
        rows.append({"component": f"PC{i + 1}", "variance_explained": ev[i], "cumulative_variance": cum[i],
                     "top_features": ", ".join(top)})
    pd.DataFrame(rows).to_csv(tab_dir / "pca_summary.csv", index=False)
    fig, ax = plt.subplots(figsize=(7, 4.5))
    ax.bar(range(1, len(ev) + 1), ev, color="#1b9e77", label="per component")
    ax.plot(range(1, len(ev) + 1), cum, marker="o", color="#d95f02", label="cumulative")
    ax.axhline(0.9, ls="--", color="grey")
    ax.set_xlabel("Principal component")
    ax.set_ylabel("Variance explained")
    ax.set_title(f"PCA scree plot ({n90} components reach 90%)")
    ax.legend()
    save_fig(fig, fig_dir / "07_pca_scree.png")

    # choose k
    ks = list(range(2, min(6, len(d) - 1) + 1))
    sel = []
    for k in ks:
        km = KMeans(n_clusters=k, n_init=10, random_state=SEED).fit(Z)
        hc = AgglomerativeClustering(n_clusters=k, linkage="ward").fit(Z)
        sel.append({"k": k, "inertia": km.inertia_, "silhouette_kmeans": silhouette_score(Z, km.labels_),
                    "silhouette_hierarchical": silhouette_score(Z, hc.labels_)})
    sel = pd.DataFrame(sel)
    sel.to_csv(tab_dir / "kmeans_selection.csv", index=False)
    best_k = int(sel.loc[sel["silhouette_kmeans"].idxmax(), "k"])
    fig, ax = plt.subplots(1, 2, figsize=(11, 4.2))
    ax[0].plot(sel["k"], sel["inertia"], marker="o", color="#1b9e77")
    ax[0].set_title("Elbow method: inertia vs k")
    ax[0].set_xlabel("k")
    ax[0].set_ylabel("Inertia")
    ax[1].plot(sel["k"], sel["silhouette_kmeans"], marker="o", label="K-Means", color="#d95f02")
    ax[1].plot(sel["k"], sel["silhouette_hierarchical"], marker="s", label="Hierarchical", color="#7570b3")
    ax[1].set_title("Silhouette score vs k")
    ax[1].set_xlabel("k")
    ax[1].legend()
    save_fig(fig, fig_dir / "08_kmeans_selection.png")

    km = KMeans(n_clusters=best_k, n_init=10, random_state=SEED).fit(Z)
    d["cluster"] = km.labels_
    d[["state", "cluster"]].to_csv(tab_dir / "cluster_assignments.csv", index=False)
    summ = d.groupby("cluster")[kept + ["total_ev"]].mean().round(3)
    summ.insert(0, "n_states", d.groupby("cluster").size())
    summ.insert(1, "example_states", d.sort_values("total_ev", ascending=False).groupby("cluster")["state"]
                .apply(lambda s: ", ".join(s.head(4))))
    summ["profile_name"] = ""     # name the clusters yourself after reading the table
    summ.to_csv(tab_dir / "cluster_summary.csv")

    P = PCA(n_components=2, random_state=SEED).fit_transform(Z)
    fig, ax = plt.subplots(figsize=(9, 6.5))
    sc = ax.scatter(P[:, 0], P[:, 1], c=d["cluster"], cmap="viridis", s=60)
    for i, s in enumerate(d["state"]):
        ax.annotate(s, (P[i, 0], P[i, 1]), fontsize=7, xytext=(3, 3), textcoords="offset points")
    ax.set_xlabel("PC1")
    ax.set_ylabel("PC2")
    ax.set_title(f"K-Means clusters (k={best_k}) on the first two principal components")
    ax.legend(*sc.legend_elements(), title="Cluster")
    save_fig(fig, fig_dir / "09_clusters_pca.png")
    return {"selection": sel, "best_k": best_k, "features": kept, "n_pc_90": n90}


# --------------------------------------------------------------------------- #
# Self-test data (synthetic - only to check that the code runs)
# --------------------------------------------------------------------------- #
def make_selftest_data(data_dir):
    rng = np.random.default_rng(SEED)
    states = [s for s in CANONICAL_STATES if s != "Telangana"][:30]
    months = [f"2025-{m:02d}" for m in range(1, 13)]
    rows = []
    size = rng.lognormal(10.5, 0.9, len(states))
    for si, s in enumerate(states):
        for mi, m in enumerate(months):
            for cat, cs in zip(["2W", "3W", "4W", "Bus"], [0.7, 0.15, 0.13, 0.02]):
                total = max(50, rng.normal(size[si] * cs / 12, size[si] * cs / 60))
                share = np.clip(rng.normal(0.02 + 0.2 * (cat == "3W") + 0.0015 * mi + 0.01 * (si % 5), 0.01), 0.001, 0.6)
                rows.append([s, m, cat, int(total * share), int(total)])
    df = pd.DataFrame(rows, columns=REQUIRED_COLS)
    # deliberately messy rows so the cleaning code is exercised
    df.loc[3, "state"] = df.loc[3, "state"].upper()
    df.loc[10, "state"] = "Orissa"
    df.loc[20, "ev_registrations"] = np.nan
    df.loc[30, "total_registrations"] = np.nan
    df.loc[40, "ev_registrations"] = -5
    df.loc[50, "ev_registrations"] = df.loc[50, "total_registrations"] + 100
    df = pd.concat([df, df.iloc[[5, 6]], pd.DataFrame([["Bihar", "2024-12", "2W", 10, 100]], columns=REQUIRED_COLS)],
                   ignore_index=True)
    ch = pd.DataFrame({"state": states, "public_charging_stations": (size / 40 * rng.uniform(0.5, 1.5, len(states))).astype(int)})
    data_dir.mkdir(parents=True, exist_ok=True)
    df.to_csv(data_dir / "ev_registrations.csv", index=False)
    ch.to_csv(data_dir / "charging_stations.csv", index=False)


# --------------------------------------------------------------------------- #
# Main
# --------------------------------------------------------------------------- #
def main():
    global WATERMARK
    ap = argparse.ArgumentParser(description="EV adoption analysis pipeline")
    ap.add_argument("--data-dir", default="data")
    ap.add_argument("--out-dir", default="outputs")
    ap.add_argument("--selftest", action="store_true", help="run on synthetic data to test the setup (NOT for the report)")
    a = ap.parse_args()

    if a.selftest:
        WATERMARK = True
        out = Path("outputs_selftest")
        data_dir = out / "data"
        log("!" * 70)
        log("SELFTEST: synthetic data generated by this script. NOT real. Do not use in the report.")
        log("!" * 70)
        make_selftest_data(data_dir)
    else:
        out, data_dir = Path(a.out_dir), Path(a.data_dir)
    fig_dir, tab_dir = out / "figures", out / "tables"
    fig_dir.mkdir(parents=True, exist_ok=True)
    tab_dir.mkdir(parents=True, exist_ok=True)

    reg_path = data_dir / "ev_registrations.csv"
    if not reg_path.exists():
        sys.exit(f"Cannot find {reg_path}. See Appendix B of the report for how to export it from VAHAN.")

    log("[1/7] Loading and cleaning data")
    raw = pd.read_csv(reg_path)
    clean, qlog = clean_registrations(raw)
    qlog.to_df().to_csv(tab_dir / "data_quality_report.csv", index=False)
    log(qlog.to_df().to_string(index=False))
    if clean.empty:
        sys.exit("No rows left after cleaning. Check the month format (YYYY-MM) and column names.")
    if "Telangana" not in set(clean["state"]):
        log("   NOTE: Telangana not present (VAHAN has no Telangana retail data). Document this as a data gap.")
    charging = load_charging(data_dir / "charging_stations.csv")
    if charging is not None:
        missing = sorted(set(clean["state"]) - set(charging["state"]))
        if missing:
            log(f"   states with no charging-station value (median used): {missing}")

    log("[2/7] Building state-level features")
    st, months = build_state_features(clean, charging)
    st.to_csv(tab_dir / "state_features.csv", index=False)
    log(f"   {len(st)} states, {len(months)} months ({months[0]:%Y-%m} to {months[-1]:%Y-%m})")

    log("[3/7] EDA figures")
    eda_figures(clean, st, fig_dir)

    log("[4/7] Statistical analysis")
    tests, pairs = statistical_analysis(clean, st, tab_dir)

    log("[5/7] Regression (Linear Regression, Decision Tree)")
    panel, feats, n_months = build_panel(clean, charging)
    reg = regression_models(panel, feats, n_months, tab_dir, fig_dir) if n_months >= 4 else None
    if reg is None and n_months < 4:
        log("   need at least 4 months of data for the time-based split - skipped.")

    log("[6/7] Classification (Decision Tree, Logistic Regression, KNN)")
    cls = classification_models(st, tab_dir, fig_dir)

    log("[7/7] PCA and clustering (K-Means, hierarchical)")
    clu = pca_and_clustering(st, tab_dir, fig_dir)

    summary = {
        "selftest_synthetic_data": bool(a.selftest),
        "rows_clean": int(len(clean)), "states": int(len(st)),
        "period": f"{months[0]:%Y-%m} to {months[-1]:%Y-%m}",
        "top5_states_by_ev": st.nlargest(5, "total_ev")[["state", "total_ev"]].to_dict("records"),
        "top5_states_by_ev_share": st.nlargest(5, "ev_share_pct")[["state", "ev_share_pct"]].to_dict("records"),
        "regression": None if reg is None else {
            "train_months": reg["train_months"], "test_months": reg["test_months"],
            "decision_tree_best_params": reg["best_params"],
            "metrics": reg["metrics"].round(4).to_dict("records"),
            "feature_importance": reg["importance"].round(4).to_dict("records")},
        "classification": None if cls is None else {
            "features": cls["features"], "best_model": cls["best"],
            "metrics": cls["metrics"].round(4).to_dict("records")},
        "clustering": None if clu is None else {
            "features": clu["features"], "best_k": clu["best_k"], "components_for_90pct_variance": clu["n_pc_90"],
            "selection": clu["selection"].round(4).to_dict("records")},
    }
    with open(tab_dir / "results_summary.json", "w") as f:
        json.dump(summary, f, indent=2, default=str)
    log(f"\nDone. Tables: {tab_dir}  Figures: {fig_dir}")
    if a.selftest:
        log("REMINDER: these outputs are from SYNTHETIC data. Do not copy them into the report.")


if __name__ == "__main__":
    main()
